
Livelink(streamlit) - https://shubham-leo-review-ranking-model-app-g3mzpr.streamlitapp.com/
Videos link - https://drive.google.com/drive/folders/1Kucx2b-famYDqWjU4pIsEmJobuYbcDYR?usp=sharing


Steps to build model – 

1.	load the libraries required for data processing
2.	Importing stop words from nltk module
3.	We clean dataset using regex to remove not needed characters 
4.	Then we remove stop words from dataset
5.	We check for Condition, if it is not stop word we lemmatize and append into a list and use that as dataframe
6.	After this pre-processing on dataframe we use sentiment analysis
7.	we check and print sentiment and compound scores of each sentence
8.	then add threshold value to categorize if a given sentence is positive negative or neutral in nature.
9.	We filter out reviews where sentiment rating does not match with stars
10.	now for predictions we use tfidf vectorization, which Convert a collection of raw documents to a matrix of TF-IDF features
11.	We compare all prediction methods on model and find best working method for prediction



Steps to build streamlit app(successful deployment on steamlit)-

1.	We created a basic streamlit file
2.	To get requirement.txt file run code ()
3.	then open streamlit.io link created new project linked it with github repository
4.	then complied it for deployment
5.	ran the code using csv
 

 
Steps to build flask app (failed deployment on Heroku)-

1.	We created 2 html file for UI
2.	First to get csv from user
3.	And second is for display the result 
4.	We apply above code in flask and ran it
5.	Created requirement.txt file using (pip freeze >requirement.txt)
6.	Then installed gunicorn for server
7.	Tested on local host it worked fine
8.	For deployment linked github repository to the Heroku 
9.	Changed the Buildpacks to python
10.	And complied it but failed to deploy
